//
//  ProductsView.swift
//  Demo
//
//  Created by Amod Kumar on 20/03/24.
//

import SwiftUI

struct ProductsView: View {
    var body: some View {
        
        let products:[Product] = ProductList().products
        
        NavigationView {
            List(products){ product in
//                NavigationLink(
//                    destination: ProductDetailsView(product: product),
//                    label:{
                        
                        HStack(spacing:40){
                            Image(systemName: product.image)
                                .resizable()
                                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                                .frame(width: 40, height: 50)
                            
                            VStack(alignment:.leading){
                                Text(product.name)
                                    .font(.system(size:20,weight: .bold))
                                
                                Text(product.category)
                                    .font(.system(size:15,weight: .bold))
                                    .foregroundColor(.gray)
                            }
                        }
                        .padding(5)

//                    })
            }
            .navigationTitle("All Products")
        }
        
    }
}

#Preview {
    ProductsView()
}
