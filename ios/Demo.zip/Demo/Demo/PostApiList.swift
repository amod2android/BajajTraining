//
//  ProductApiList.swift
//  Demo
//
//  Created by Amod Kumar on 25/03/24.
//

import SwiftUI

struct PostApiList: View {
    @State var postItems : [PostItem.data]
    @State var model: PostItem?
    var body: some View {
        
        NavigationView {
            List(postItems , id:\.id){ post in
                
                VStack(alignment: .leading, spacing: 16) {
                    
                    Text(post.authorName)
                        .font(.headline)
                        .padding(.horizontal)
                    
                    // Post Content
                    Text(post.content)
                        .font(.body)
                        .padding(.horizontal)
                    
                    // Post Image
                    AsyncImage(
                        url: URL(string: post.imageUrl),
                        content: { image in
                            image.resizable()
                        },
                        placeholder: {
                            ProgressView()
                        }
                    )
                    .aspectRatio(contentMode: .fit)
                    .frame(maxHeight: 300)
                    
                    // Post Actions (e.g., Like, Comment, Share)
                    HStack {
                        Button(action: {
                            deletePost(post : post)
                        }) {
                            Image(systemName: "trash")
                                .foregroundColor(.blue)
                        }
                        .padding()
                    
                        Spacer()
                    }
                    .padding(.horizontal)
                }
                
                
            }
            .navigationTitle("All Posts")
        }
        .task {
            await getPosts()
            print(postItems)
        }
    }
    
    func getPosts() async
    {
        guard let url = URL(string: "http://localhost:8080/api/v1/post/all") else {
            print("Ivalid URL")
            return
        }
        
        do{
            let (data,_) = try await URLSession.shared.data(from: url)
            
            let decodedData = try JSONDecoder().decode(PostItem.self, from: data)
            
            model = decodedData
            
            postItems = model?.data ?? []
            
        }
        catch{
            print(error.localizedDescription)
        }
        
    }
}


func deletePost(post : PostItem.data) {
    
    guard let url = URL(string: "http://localhost:8080/api/v1/post/\(post.id)") else {
        print("Invalid URL")
        return
    }
    
    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let _ = data, error == nil else {
            print("Error: \(error?.localizedDescription ?? "Unknown error")")
            return
        }
                    
    }.resume()
}


#Preview {
    PostApiList(postItems: [])
}


struct PostItem: Codable {
    
    let data: [data]
    let message: String
    
    struct data: Codable {
        let id:Int
        let authorName:String
        let content:String
        let imageUrl:String
    }
}
