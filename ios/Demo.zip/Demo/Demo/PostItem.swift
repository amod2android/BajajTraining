//
//  PostItem.swift
//  Demo
//
//  Created by Amod Kumar on 29/03/24.
//

import SwiftUI

struct PostItem: View {
    var body: some View {
       VStack(alignment: .leading, spacing: 16) {
         // Post Header
           VStack(alignment: .leading, spacing: 4) {
               Text("John Doe")
                   .font(.headline)
           }.padding(.horizontal)
                // Post Content
                Text("Hello world! This is a sample post on SwiftUI.")
                    .font(.body)
                    .padding(.horizontal)
                
                // Post Image
                Image(systemName: "cloud.sun")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxHeight: 300)
                    .padding(8)
            }
        .navigationBarTitle("Post")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PostItem()
    }
}
