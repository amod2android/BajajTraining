//
//  PostsViewModel.swift
//  Demo
//
//  Created by Amod Kumar on 29/03/24.
//

import SwiftUI
// ViewModel
class PostsViewModel : ObservableObject {

     var model: PostItem?
    @Published var posts: [PostItem.data] = []
    
    func fetchPosts() {
        
        guard let url = URL(string: "http://localhost:8080/api/v1/post/all") else {
            print("Invalid URL")
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            if let decodedPosts = try? JSONDecoder().decode(PostItem.self, from: data) {
                DispatchQueue.main.async {
                    self.model = decodedPosts
                    self.posts = self.model?.data ?? []
                }
            }
        }.resume()
    }
    
    func deletePost(at index: Int) {
        let post = posts[index]
        guard let url = URL(string: "http://localhost:8080/api/v1/post/\(post.id)") else {
            print("Invalid URL")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            DispatchQueue.main.async {
                self.posts.remove(at: index)
            }
        }.resume()
    }
}
