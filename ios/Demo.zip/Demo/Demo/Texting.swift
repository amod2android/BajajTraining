//
//  Texting.swift
//  Demo
//
//  Created by Amod Kumar on 28/03/24.
//

import SwiftUI

struct Texting: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    Texting()
}
