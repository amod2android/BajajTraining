//
//  PostList.swift
//  Demo
//
//  Created by Amod Kumar on 29/03/24.
//

import SwiftUI

struct PostList: View {
    @StateObject private var viewModel = PostsViewModel()
    var body: some View {
           List {
               ForEach(viewModel.posts,id: \.self) { post in
                   VStack(alignment: .leading) {
                       Text(post.authorName)
                           .font(.headline)
                       Text(post.content)
                           .font(.subheadline)
                           .foregroundColor(.secondary)
                   }
               }
               .onDelete(perform: viewModel.deletePost)
           }
           .onAppear {
               viewModel.fetchPosts()
           }
       }
}

// Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PostList()
    }
}
