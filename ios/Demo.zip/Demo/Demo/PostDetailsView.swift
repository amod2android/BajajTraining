//
//  ProductDetailsView.swift
//  Demo
//
//  Created by Amod Kumar on 20/03/24.
//

import SwiftUI

struct PostDetailsView: View {
    var product: PostItem
    
    var body: some View {
        
        VStack {
            
            // Half of the page for the image
            AsyncImage(
                url: URL(string: product.imageUrl),
                content: { image in
                    image.resizable()
                },
                placeholder: {
                    ProgressView()
                }
                
            )
            .aspectRatio(contentMode: .fit)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .padding(20)
            
            // Half of the page for text details
            VStack(alignment: .leading, spacing: 16) {
                Text(product.content)
                    .font(.title)
                    .padding(.top, 16)
                    .padding(.horizontal)
                
                Text("Name : \(product.authorName)")
                    .font(.body)
                    .padding(.horizontal)
                
                Text("Description : \(product.authorName)")
                    .font(.body)
                    .padding(.horizontal)
                
                Text("Price : \(product.price)")
                    .font(.body)
                    .padding(.horizontal)
                
                Spacer()
            }
        }
    }
}

//#Preview {
//    ProductDetailsView(product: ProductItem(_id: "", name: "Graphic T-Shirt", price: 29.99, imageUrl: "https://media.istockphoto.com/id/1452313255/photo/t-shirt-design.webp?b=1&s=170667a&w=0&k=20&c=Lanc-h6oXq8qnUnto9GJGwSM1CMw9Z7D73gdtqcDino=", category: "Fashion"))
// 
//}
