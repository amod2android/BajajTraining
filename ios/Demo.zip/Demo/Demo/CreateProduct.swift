//
//  CreateProduct.swift
//  Demo
//
//  Created by Amod Kumar on 21/03/24.
//

import SwiftUI

struct CreateProduct: View {
    
    @State var name : String = ""
    @State var imageUrl : String = ""
    @State var category : String = ""
    @State var price : String = ""
    @State var isAvailavle : Bool = false
    @State var rDate = Date()
    
    var body: some View {
        NavigationView{
            Form{
                Section("Product Details",content: {
                    TextField("Enter Product Name", text:$name)
                    TextField("Enter Product Price", text:$price)
                    DatePicker("Select Released date", selection: $rDate, displayedComponents: .date)
                })
                Section("Additional Details",content: {
                    TextField("Enter Image Url", text:$imageUrl)
                    TextField("Enter Category", text:$category)
                    Toggle("Is Available", isOn:$isAvailavle)
                })
                
            }
            .navigationTitle("Create Product")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button{
                      print("Saved")
                        
                    }label:{
                        Text("Save")
                    }
                }
            }
        }
    }
}
    
#Preview {
        CreateProduct()
    }
