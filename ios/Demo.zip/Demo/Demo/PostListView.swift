//
//  PostListView.swift
//  Demo
//
//  Created by Amod Kumar on 29/03/24.
//

import SwiftUI

//struct PostListView: View {
//    let posts: [Post] = [
//        Post(author: "John Doe", content: "Hello world! This is a sample post on SwiftUI.", imageUrl: "post_image"),
//        Post(author: "Jane Smith", content: "Check out this amazing SwiftUI tutorial.", imageUrl: nil)
//    ]
    
//    var body: some View {
//        NavigationView {
//            List(posts) { post in
//                NavigationLink(destination: ContentView(post: post)) {
//                    VStack(alignment: .leading, spacing: 8) {
//                        Text(post.author)
//                            .font(.headline)
//                        Text(post.content)
//                            .font(.subheadline)
//                            .foregroundColor(.gray)
//                            .lineLimit(2)
//                        if let imageUrl = post.imageUrl {
//                            Image(imageUrl)
//                                .resizable()
//                                .aspectRatio(contentMode: .fill)
//                                .frame(height: 200)
//                                .clipped()
//                        }
//                    }
//                    .padding()
//                }
//            }
//            .navigationBarTitle("Posts")
//        }
//    }
//}

//struct PostListView_Previews: PreviewProvider {
//    static var previews: some View {
//        PostListView()
//    }
//}
