//
//  ContentView.swift
//  Demo
//
//  Created by Amod Kumar on 19/03/24.
//

import SwiftUI

struct WeatherView: View {
    
    @State var darkMode :Bool = true
    
    var body: some View {
        ZStack{
            Color(darkMode ? .black : .blue)
        
            VStack {
                VStack{
                    Text("Mumbai, India")
                        .font(.system(size: 30,weight: .bold))
                        .foregroundColor(.white)
                    Text("Today")
                        .foregroundColor(.white)
                    
                    Spacer()
                    
                    Image(systemName: "cloud.sun")
                        .resizable()
                        .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                        .frame(width: 100, height: 100)
                    
                    Text("10°")
                        .foregroundColor(.white)
                        .font(.system(size: 100))
                    Spacer()
                    
                    VStack{
                        Text("Tommorow")
                            .foregroundColor(.white)
                        
                        HStack(spacing:10){
                            Image(systemName: "cloud.rain")
                                .resizable()
                                .aspectRatio(contentMode: /*@START_MENU_TOKEN@*/.fill/*@END_MENU_TOKEN@*/)
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                            Text("5°")
                                .foregroundColor(.white)
                                .font(.system(size: 40))
                        }
                    }
                    
                    Spacer()
                    
                    HStack{
                        DayItem(day:"S",temp:"-2",dMode:darkMode)
                        DayItem(day:"M",temp:"-3",dMode:darkMode)
                        DayItem(day:"T",temp:"-4",dMode:darkMode)
                        DayItem(day:"W",temp:"-5",dMode:darkMode)
                        DayItem(day:"T",temp:"-6",dMode:darkMode)
                        DayItem(day:"F",temp:"-7",dMode:darkMode)
                        DayItem(day:"S",temp:"-8",dMode:darkMode)
                    }
                    Spacer()
                    
                    Button{
          
                        darkMode.toggle()
                    } label : {
                        Text("Change Mode")
                            .font(.system(size: 25, weight: .medium))
                            .foregroundStyle(darkMode ? .black : .white)
                            .frame(width: 200, height: 70)
                            .background(darkMode ? .white : .black)
                            .cornerRadius(10)
                        
                    }
                    
                }
                
            }
            .padding(.vertical,40)
        }
    }
}

#Preview {
    WeatherView()
}

struct DayItem: View {
    var day:String
    var temp:String
    var dMode:Bool
    
    var body: some View {
        VStack(spacing:3){
            Text(day)
                .foregroundColor(.white)
                .font(.system(size: 20))
            Text("\(temp)°")
                .foregroundColor(.white)
                .font(.system(size: 20))
            
        }
    }
}
