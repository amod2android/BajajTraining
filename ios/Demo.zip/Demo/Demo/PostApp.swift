//
//  DemoApp.swift
//  Demo
//
//  Created by Amod Kumar on 26/03/24.
//

import SwiftUI

@main
struct PostApp: App {
    var body: some Scene {
        WindowGroup {
            PostApiList(postItems: [])
        }
    }
}
