//
//  PostDetails.swift
//  Demo
//
//  Created by Amod Kumar on 26/03/24.
//

import SwiftUI



struct PostDetails: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
              
                Text("John Doe")
                    .font(.headline)
                
                // Post Content
                Text("Hello world! This is a sample post on SwiftUI.")
                    .font(.body)
                    .padding(.horizontal)
                
                // Post Image
                Image("post_image")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxHeight: 300)
                
                // Post Actions (e.g., Like, Comment, Share)
//                HStack {
//                    Button(action: {
//                        // Like action
//                    }) {
//                        Image(systemName: "heart")
//                            .foregroundColor(.blue)
//                    }
//                    .padding()
//                    
//                    Button(action: {
//                        // Comment action
//                    }) {
//                        Image(systemName: "bubble.left")
//                            .foregroundColor(.blue)
//                    }
//                    .padding()
//                    
//                    Button(action: {
//                        // Share action
//                    }) {
//                        Image(systemName: "arrowshape.turn.up.right")
//                            .foregroundColor(.blue)
//                    }
//                    .padding()
//                    
//                    Spacer()
//                }
//                .padding(.horizontal)
            }
        }
        .navigationBarTitle("Post")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        PostDetails()
    }
}
