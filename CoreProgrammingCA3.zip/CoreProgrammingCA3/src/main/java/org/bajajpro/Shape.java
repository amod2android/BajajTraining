package org.bajajpro;

public interface Shape {
    public void area();

    public void displayInfo();


}
